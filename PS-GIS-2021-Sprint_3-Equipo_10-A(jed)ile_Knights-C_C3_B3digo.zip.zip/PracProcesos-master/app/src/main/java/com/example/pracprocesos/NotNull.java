package com.example.pracprocesos;

public @interface NotNull {
}
